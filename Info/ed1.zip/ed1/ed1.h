/*
 * ed1
 *
 * A library for the NICTA ed1 board
 * Copyright (c) 2010 Michael Cahill <michael@ncss.edu.au>
 *
 * This file is licensed to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 * Implements classes for the accelerometer and eeprom on the I2C bus.
 */


#ifndef ed1_h
#define ed1_h

#include <inttypes.h>
//#include "WProgram.h"
#include "Arduino.h"
#include "Wire.h"

/*
 * Valid accelerometer modes
 */
#define ACCEL_MEASURE_2G_MODE 0x05
#define ACCEL_MEASURE_4G_MODE 0x09
#define ACCEL_MEASURE_8G_MODE 0x01
#define ACCEL_PULSE_MODE 0x03
#define ACCEL_LEVEL_MODE 0x02


/*
 * Wrap accelerometer functions in a class library
 */

class ed1_Accelerometer
{
  private:
    uint8_t part_address;
    void send_byte(uint8_t, uint8_t);
    uint8_t read_byte(uint8_t);
  public:
    ed1_Accelerometer(uint8_t);
    int begin(int);
    char readX(void);
    char readY(void);
    char readZ(void);
    int calibrate(void);
};

extern ed1_Accelerometer Accel;

class ed1_Eeprom
{
  private:
    uint8_t part_address;
    void send_byte(int, uint8_t);
    uint8_t read_byte(int);
  public:
    ed1_Eeprom(uint8_t);
    void begin(void);
    void sendB(int, uint8_t);
    uint8_t readB(int);
    void sendI(int, int);
    int readI(int);
    void sendL(int, long);
    long readL(int);
    void sendF(int, float);
    float readF(int);
};

extern ed1_Eeprom EEPROM_ed1;

#endif

