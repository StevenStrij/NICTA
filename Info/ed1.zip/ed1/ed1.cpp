/*
 * ed1
 *
 * A library for the NICTA ed1 board
 * Copyright (c) 2010 Michael Cahill <michael@ncss.edu.au>
 *
 * This file is licensed to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */


//#include "WProgram.h"
#include "ed1.h"

/*
 * Glabel vars
 */

// flag to remember if wire library has been initiated
static int wire_library_initiated = 0;

/*
 * Initialise accelerometer object with address of part
 */
ed1_Accelerometer::ed1_Accelerometer(uint8_t address)
{
  // simply record I2C address of accelerometer
  part_address = address;
}

/*
 * Send single uint8_t to part
 */
void ed1_Accelerometer::send_byte(byte reg, uint8_t val)
{
  Wire.beginTransmission(part_address);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();

  //delay to make sure data is written
  delay(10);
}

/*
 * Read single uint8_t from part
 */
byte ed1_Accelerometer::read_byte(byte reg)
{
  Wire.beginTransmission(part_address);
  Wire.write(reg);
  Wire.endTransmission();

  Wire.requestFrom(part_address,  uint8_t(1));
  while (!Wire.available())
      ;
  return(Wire.read());
}

/*
 * Put into desired mode
 */
int ed1_Accelerometer::begin(int mode)
{
  uint8_t check_mode;
  uint8_t reg = 0x16;

  switch (mode) {
    case ACCEL_MEASURE_2G_MODE:
      break;

    default:
      return -1;
  }

  // initiate Wire library if not done
  if (!wire_library_initiated) {
    Wire.begin();
    wire_library_initiated = 1;
  }
 
  // write status uint8_t
  send_byte(reg, (uint8_t)mode);

  // read to confirm part is responding
  check_mode = read_byte(reg);
  if (check_mode != (uint8_t)mode)
    return(-1);

  return(0);
}

/*
 * Functions to return signed 8 bit accelerometer readings
 */
char ed1_Accelerometer::readX(void)
{
  uint8_t reg = 0x06;
  return( (char)read_byte(reg) );
}

char ed1_Accelerometer::readY(void)
{
  uint8_t reg = 0x07;
  return( (char)read_byte(reg) );
}
  
char ed1_Accelerometer::readZ(void)
{
  uint8_t reg = 0x08;
  return( (char)read_byte(reg) );
}

int ed1_Accelerometer::calibrate(void)
{
  char x, y, z;
  int xcal, ycal, zcal;
  int result;
  int passes = 10;
  int i;
  
  xcal = 0;
  ycal = 0;
  zcal = 0;
  
  for (i = 0; i < passes; i++) {
    x = readX();
    y = readY();
    z = readZ();
    xcal += -2 * (int)x;
    ycal += -2 * (int)y;
    zcal += (64 - (int)z) * 2;
    //zcal += (-64 - (int)z) * 2;
    
    send_byte(0x10, (byte)(xcal & 0x00ff));
    send_byte(0x11, (byte)(xcal >> 8));
    send_byte(0x12, (byte)(ycal & 0x00ff));
    send_byte(0x13, (byte)(ycal >> 8));
    send_byte(0x14, (byte)(zcal & 0x00ff));
    send_byte(0x15, (byte)(zcal >> 8));
    
    delay(10);
  }
  
  return 0; 
}

// EEPROM

/*
 * Initialise eeprom object with address of part
 */
ed1_Eeprom::ed1_Eeprom(uint8_t address)
{
  // simply record I2C address of accelerometer
  part_address = address;
}

/*
 * Send single uint8_t to eeprom
 */
void ed1_Eeprom::send_byte(int address, uint8_t val)
{
  Wire.beginTransmission(part_address);
  Wire.write((uint8_t)(address >> 8));     // high address byte
  Wire.write((uint8_t)(address & 0x00ff)); // low address byte
  Wire.write(val);
  Wire.endTransmission();

  //delay to make sure data is written to eeprom
  delay(5);
}

/*
 * Read single uint8_t from eeprom
 */
uint8_t ed1_Eeprom::read_byte(int address)
{
  Wire.beginTransmission(part_address);
  Wire.write((uint8_t)(address >> 8));     // high address byte
  Wire.write((uint8_t)(address & 0x00ff)); // low address byte
  Wire.endTransmission();

  Wire.requestFrom(part_address,  uint8_t(1));
  while (!Wire.available())
      ;
  return(Wire.read());
}

/*
 * Initialise, just start the Wire class if not done already
 */
void ed1_Eeprom::begin(void)
{
  // initiate Wire library if not done
  if (!wire_library_initiated) {
    Wire.begin();
    wire_library_initiated = 1;
  }
}

void ed1_Eeprom::sendB(int address, uint8_t val)
{
  send_byte(address, val);
}

uint8_t ed1_Eeprom::readB(int address)
{
  return(read_byte(address));
}

void ed1_Eeprom::sendI(int address, int val)
{
  int i;
  uint8_t *p;
  
  p = (uint8_t*)&val;
  for(i = 0; i < sizeof(val); i++) {
    send_byte(address+i, *p);
    p++;
  }
}

int ed1_Eeprom::readI(int address)
{
  int i;
  int val;
  uint8_t *p;
  
  p = (uint8_t*)&val;
  for(i = 0; i < sizeof(val); i++) {
    *p = read_byte(address+i);
    p++;
  }
  
  return(val);
}

void ed1_Eeprom::sendL(int address, long val)
{
  int i;
  uint8_t *p;
  
  p = (uint8_t*)&val;
  for(i = 0; i < sizeof(val); i++) {
    send_byte(address+i, *p);
    p++;
  }
}

long ed1_Eeprom::readL(int address)
{
  int i;
  long val;
  uint8_t *p;
  
  p = (uint8_t*)&val;
  for(i = 0; i < sizeof(val); i++) {
    *p = read_byte(address+i);
    p++;
  }
  
  return(val);
}

void ed1_Eeprom::sendF(int address, float val)
{
  int i;
  uint8_t *p;
  
  p = (uint8_t*)&val;
  for(i = 0; i < sizeof(val); i++) {
    send_byte(address+i, *p);
    p++;
  }
}

float ed1_Eeprom::readF(int address)
{
  int i;
  float val;
  uint8_t *p;
  
  p = (uint8_t*)&val;
  for(i = 0; i < sizeof(val); i++) {
    *p = read_byte(address+i);
    p++;
  }
  
  return(val);
}

/*
 * Create instance of classes, provide part addresses
 */
ed1_Accelerometer Accel(0x1D);
ed1_Eeprom EEPROM_ed1(0x51);
